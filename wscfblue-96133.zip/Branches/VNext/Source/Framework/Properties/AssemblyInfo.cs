﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WSCF.blue Framework")]
[assembly: AssemblyDescription("The core components of WSCF.blue.")]
[assembly: ComVisible(false)]
[assembly: InternalsVisibleTo("Thinktecture.Wscf.Framework.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100a9f505afe4278fd6f6eeb18a98abfe04839bc08e158a406797089ae18ad56d78ecba382e61bbb86f46d876c506377af60eb2a74e2bfc0a20c8e4220e8144ec50853fbd387fd70cdc5eb7e6de58e7f3d6cf06ce70644f0100f987cce5c1217164a9fdec56d991d59ebe6679b4f5c5c7fa8c14dc7ecc78107d5e65ef007209c1e8")]