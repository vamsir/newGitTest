﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WSCF.blue Framework Unit Tests")]
[assembly: AssemblyDescription("Unit tests for the core components of WSCF.blue.")]
[assembly: ComVisible(false)]