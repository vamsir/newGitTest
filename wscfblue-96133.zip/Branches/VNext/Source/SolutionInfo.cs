﻿using System.Reflection;

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("thinktecture")]
[assembly: AssemblyProduct("WSCF.blue")]
[assembly: AssemblyCopyright("Copyright © 2002-2010 by thinktecture, Ingo Rammer and Christian Weyer. All rights reserved.")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyName("")]