using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Web Services Contract-First")]
[assembly: AssemblyDescription("Web Services Contract-First code generator for Visual Studio .NET 2008.")]
[assembly: ComVisible(true)]