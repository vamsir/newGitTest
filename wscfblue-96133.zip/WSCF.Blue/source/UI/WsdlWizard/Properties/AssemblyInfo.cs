using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: AssemblyTitle("Web Services WSDL Creation Wizard")]
[assembly: AssemblyDescription("Web Service WSDL Creation wizard.")]
[assembly: FileIOPermission(SecurityAction.RequestMinimum, Unrestricted = true)]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]