﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("UI Dialogs")]
[assembly: AssemblyDescription("User interface for WSCF.blue options and configuration.")]
[assembly: ComVisible(false)]