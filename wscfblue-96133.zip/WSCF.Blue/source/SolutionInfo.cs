﻿using System.Reflection;

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("thinktecture")]
[assembly: AssemblyProduct("WSCF.blue")]
[assembly: AssemblyCopyright("© 2002-2009 by thinktecture, Ingo Rammer and Christian Weyer. All rights reserved.")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyName("")]