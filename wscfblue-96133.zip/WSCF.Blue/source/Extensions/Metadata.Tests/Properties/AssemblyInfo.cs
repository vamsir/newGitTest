﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Thinktecture.ServiceModel.Extensions.Metadata.Tests")]
[assembly: AssemblyDescription("Unit tests for the WCF metadata extension.")]
[assembly: ComVisible(false)]