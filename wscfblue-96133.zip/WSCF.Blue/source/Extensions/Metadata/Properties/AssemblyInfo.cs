﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Thinktecture.ServiceModel.Extensions.Metadata")]
[assembly: AssemblyDescription("WCF extensions for custom metadata manipulation.")]
[assembly: CLSCompliant(true)]
[assembly: ComVisible(false)]
