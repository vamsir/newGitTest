﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Thinktecture.Tools.Wscf.Services.CodeGeneration.Tests
{


    /*
     * (1)	Special case of DCG allows to select the elements and their 
     * correct names which form the root of the message
     * 
     * (2) Tests for advanced options such as Wrapping
     * 
     * 
     * */


    /// <summary>
    /// Summary description for MessageContractGeneratorTests
    /// </summary>
    [TestFixture]
    public class MessageContractGeneratorTests
    {


        [Test]
        public void TestMethod1()
        {
            //
            // TODO: Add test logic	here
            //
        }
    }
}
