﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Thinktecture.Tools.Wscf.Services.CodeGeneration.Tests
{

    /*
     * (1)	Generate a service given an interface contract (or a wsdl)  
     * and a servicegenerator options 
     * 
     * 
     * 
     * */
    /// <summary>
    /// Summary description for ServiceGeneratorTests
    /// </summary>
    [TestFixture]
    public class ServiceGeneratorTests
    {
        [Test]
        public void TestMethod1()
        {
            //
            // TODO: Add test logic	here
            //
        }
    }
}
