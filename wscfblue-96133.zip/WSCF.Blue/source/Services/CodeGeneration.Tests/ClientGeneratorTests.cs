﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Thinktecture.Tools.Wscf.Services.CodeGeneration.Tests
{

    /*
     * (1)	Generate a client proxy given an interface contract  
     * (or a wsdl) and client generation options
     * 
     * 
     * 
     * 
     * */
    /// <summary>
    /// Summary description for ClientGeneratorTests
    /// </summary>
    [TestFixture]
    public class ClientGeneratorTests
    {
        [Test]
        public void ShouldGenerateClientSideProxy()
        {
            throw new NotImplementedException();
        }
    }
}
