﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Thinktecture.Tools.Wscf.Services.CodeGeneration.Tests
{
    /*
     * (1)	Generate a service configuration 
        (2)	Generate a client configuration
        (3)	Merge with existing service / client configuration

     * 
     * 
     * 
     * */


    /// <summary>
    /// Summary description for ConfigurationGeneratorTests
    /// </summary>
    [TestFixture]
    public class ConfigurationGeneratorTests
    {
        [Test]
        public void ShouldGenerateDefaultServiceConfiguration()
        {
            throw new NotImplementedException();
        }


        [Test]
        public void ShouldAddBindingsToServiceConfiguration()
        {
            throw new NotImplementedException();

        }

        [Test]
        public void ShouldSetRootedEndpoint()
        {
            throw new NotImplementedException();
        }

        [Test]
        public void ShouldGenerateDefaultClientConfiguration()
        {
            throw new NotImplementedException();
        }


        [Test]
        public void ShouldAddBindingsToClientConfiguration()
        {
            throw new NotImplementedException();

        }

        [Test]
        public void ShouldMergeServiceConfiguration()
        {
            
            throw new NotImplementedException();
        }

        [Test]
        public void ShouldMergeClientConfiguration()
        {
            throw new NotImplementedException();
        }

    }
}
