﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using NUnit.Framework;

namespace Thinktecture.Tools.Wscf.Services.ServiceDescription.Tests
{

    /*
        (1)	Pass in a WSDL and  Get an interface contract class
     * */
    /// <summary>
    /// Summary description for WsdlParserTests
    /// </summary>
    [TestFixture]
    public class WsdlParserTests
    {

        [Test]
        public void ShouldParseSingleWsdl()
        {
            throw new NotImplementedException();
        }

        [Test]
        public void ShouldParseMultipartWsdl()
        {
            throw new NotImplementedException();

        }

    }
}
