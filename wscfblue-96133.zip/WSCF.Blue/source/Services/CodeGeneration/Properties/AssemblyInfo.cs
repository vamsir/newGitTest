﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Service Code Generation Library For WCF")]
[assembly: AssemblyDescription("Web Service code generation implementation.")]
[assembly: ComVisible(false)]