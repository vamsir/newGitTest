using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: AssemblyTitle("Web Services Description Engine")]
[assembly: AssemblyDescription("Web Service description generation implementation.")]
[assembly: FileIOPermission(SecurityAction.RequestMinimum, Unrestricted = true)]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]