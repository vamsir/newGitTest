﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client.HelloDemoServiceReference;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            HelloDemoServiceClient clientProxy = new HelloDemoServiceClient("WSHttpBinding_IHelloDemoService");
            Name person = new Name();
            person.First = "Bala";
            person.Last = "Ganty";
            string sayHello = clientProxy.SayHello(person);
            Console.WriteLine(sayHello);
            Console.ReadLine();
        }
    }
}
