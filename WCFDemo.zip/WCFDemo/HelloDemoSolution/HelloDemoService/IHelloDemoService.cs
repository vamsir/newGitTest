﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace HelloDemoService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IHelloDemoService" in both code and config file together.
    [ServiceContract]
    public interface IHelloDemoService
    {
        [OperationContract]
        string SayHello(Name person);

        // TODO: Add your service operations here
    }

    // Use a data contract as illustrated in the sample below to add composite types to service operations
    [DataContract]
    public class Name
    {
        string first = string.Empty;
        string last = string.Empty;

        [DataMember]
        public string First
        {
            get { return first; }
            set { first = value; }
        }

        [DataMember]
        public string Last
        {
            get { return last; }
            set { last = value; }
        }
    }
}
