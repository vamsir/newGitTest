﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace HelloDemoService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class HelloDemoService : IHelloDemoService
    {
        public string SayHello(Name person)
        {
            string sayHello = string.Format("Hello World {0} {1}",
                person.First, person.Last);
            return sayHello;
        }
    }
}
